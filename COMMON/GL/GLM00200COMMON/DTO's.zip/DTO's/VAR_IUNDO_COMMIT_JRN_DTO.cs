﻿using R_APICommonDTO;
using System;
using System.Collections.Generic;
using System.Text;

namespace GLM00200Common.DTO_s
{
    public class VAR_IUNDO_COMMIT_JRN_DTO : R_APIResultBaseDTO
    {
        public Int32 IOPTON { get; set; }

    }
}
