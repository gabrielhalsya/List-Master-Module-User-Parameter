﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GLM00200Common.DTO_s
{
    public class VAR_TODAY_DTO
    {
        public String VAR_TODAY { get; set; }
    }
}
