﻿using R_APICommonDTO;
using System;
using System.Collections.Generic;
using System.Text;

namespace GLM00200Common.DTO_s
{
    public class VAR_STATUS_DTO
    {
        public string CCODE { get; set; }
        public string CNAME { get; set; }
    }
}
