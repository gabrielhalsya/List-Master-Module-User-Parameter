﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GLM00200Common.DTO_s
{
    public class PeriodDTO
    {
        public string CPERIOD_MM_CODE { get; set; }
        public string CPERIOD_MM_TEXT { get; set; }
    }
}
