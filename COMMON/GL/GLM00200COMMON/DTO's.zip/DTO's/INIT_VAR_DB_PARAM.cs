﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GLM00200Common.DTO_s
{
    public class INIT_VAR_DB_PARAM
    {
        public string CCOMPANY_ID { get; set; } = "";
        public string CUSER_ID { get; set; } = "";
        public string CCURRENT_PERIOD_YY { get; set; } = "";
        public string CCURRENT_PERIOD_MM { get; set; } = "";
        public string CSOFT_PERIOD_YY { get; set; } = "";
        public string CSOFT_PERIOD_MM { get; set; } = "";
        public string CLANGUAGE_ID { get; set; } = ""; 
    }
}
