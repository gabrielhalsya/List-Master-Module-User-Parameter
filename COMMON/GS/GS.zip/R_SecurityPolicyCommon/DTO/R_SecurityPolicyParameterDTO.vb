﻿Public Class R_SecurityPolicyParameterDTO
    Public Property CUSER_ID As String
    Public Property CCOMPANY_ID As String
    Public Property LCHOOSE_COMPANY_AT_LOGIN_PAGE As Boolean
    Public Property CSECURITY_AND_ACCOUNT_POLICY As String
    Public Property LENFORCE_PASSWORD_HISTORY As Boolean
    Public Property IENFORCE_PASSWORD_HISTORY As Integer
    Public Property CHASH_PASSWORD As String
    Public Property CHASH_CURRENT_PASSWORD As String
    Public Property CUSER_PASSWORD As String
End Class
