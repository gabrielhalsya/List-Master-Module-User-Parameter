﻿Imports R_APICommonDTO

Public Class SecurityPolicyGenericResultDTO(Of T)
    Inherits R_APIResultBaseDTO

    Public Property Data As T
End Class

Public Class SecurityPolicyGenericResultDTO
    Inherits R_APIResultBaseDTO

End Class