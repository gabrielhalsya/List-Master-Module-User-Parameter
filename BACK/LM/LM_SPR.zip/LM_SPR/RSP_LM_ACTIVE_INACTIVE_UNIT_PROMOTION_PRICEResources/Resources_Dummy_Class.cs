﻿using System;

namespace RSP_LM_ACTIVE_INACTIVE_UNIT_PROMOTION_PRICEResources
{
    public class Resources_Dummy_Class
    {

    }
}
