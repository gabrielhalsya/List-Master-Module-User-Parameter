﻿using System;

namespace RSP_LM_MAINTAIN_UTILITY_CHARGESResources
{
    public class Resources_Dummy_Class
    {

    }
}
