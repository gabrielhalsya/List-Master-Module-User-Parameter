﻿using System;

namespace RSP_LM_MAINTAIN_SALESMANResources
{
    public class Resources_Dummy_Class
    {

    }
}
