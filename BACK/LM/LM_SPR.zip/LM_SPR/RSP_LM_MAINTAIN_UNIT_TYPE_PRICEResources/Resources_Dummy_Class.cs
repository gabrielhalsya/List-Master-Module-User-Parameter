﻿using System;

namespace RSP_LM_MAINTAIN_UNIT_TYPE_PRICEResources
{
    public class Resources_Dummy_Class
    {

    }
}
