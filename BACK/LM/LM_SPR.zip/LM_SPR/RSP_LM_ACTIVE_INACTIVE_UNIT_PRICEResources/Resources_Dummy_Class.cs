﻿using System;

namespace RSP_LM_ACTIVE_INACTIVE_UNIT_PRICEResources
{
    public class ResourceS_Dummy_Class
    {

    }
}
