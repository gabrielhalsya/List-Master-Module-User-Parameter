﻿using System;

namespace RSP_LM_MAINTAIN_UNIT_CHARGESResources
{
    public class Resources_Dummy_Class
    {

    }
}
