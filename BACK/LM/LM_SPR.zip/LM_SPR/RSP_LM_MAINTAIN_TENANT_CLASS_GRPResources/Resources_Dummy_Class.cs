﻿using System;

namespace RSP_LM_MAINTAIN_TENANT_CLASS_GRPResources
{
    public class Resources_Dummy_Class
    {

    }
}
