﻿using System;

namespace RSP_LM_MAINTAIN_TENANTResources
{
    public class Resources_Dummy_Class
    {

    }
}
