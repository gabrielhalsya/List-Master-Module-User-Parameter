﻿using System;

namespace RSP_LM_MAINTAIN_UNIT_TYPE_BILLING_RULEResources
{
    public class Resources_Dummy_Class
    {

    }
}
