﻿using System;

namespace RSP_LM_MAINTAIN_TENANT_GRPResources
{
    public class Resources_Dummy_Class
    {

    }
}
