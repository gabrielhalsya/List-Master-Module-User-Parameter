﻿using GLM00200Common;
using R_BackEnd;
using R_CommonFrontBackAPI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GLM00200Back
{
    public class GLM00201Cls : R_BusinessObject<JournalDetailGridDTO>
    {
        protected override void R_Deleting(JournalDetailGridDTO poEntity)
        {
            throw new NotImplementedException();
        }

        protected override JournalDetailGridDTO R_Display(JournalDetailGridDTO poEntity)
        {
            throw new NotImplementedException();
        }

        protected override void R_Saving(JournalDetailGridDTO poNewEntity, eCRUDMode poCRUDMode)
        {
            throw new NotImplementedException();
        }
    }
}
