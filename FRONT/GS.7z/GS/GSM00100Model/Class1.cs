﻿using System;

namespace GSM00100Model
{
    public class Class1
    {

    }
}
