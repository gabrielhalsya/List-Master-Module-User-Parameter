﻿namespace GSM00100FrontResources
{
    public class Class1
    {

    }
}
